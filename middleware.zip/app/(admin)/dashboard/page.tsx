/* eslint-disable @typescript-eslint/no-explicit-any */
import { NextPage } from "next";

const Page: NextPage<any> = ({}) => {
  return (
    <>
      Dashboard
    </>
  );
};

export default Page;
