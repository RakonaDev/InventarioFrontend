(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(auth)_login_page_tsx_04199f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(auth)_login_page_tsx_04199f._.js",
  "chunks": [
    "static/chunks/node_modules_react-icons_lu_index_mjs_26d8a9._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_axios_lib_c4c49c._.js",
    "static/chunks/node_modules_lodash-es_489b7f._.js",
    "static/chunks/node_modules_8d29e7._.js",
    "static/chunks/_91e559._.js"
  ],
  "source": "dynamic"
});
