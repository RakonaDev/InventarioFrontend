(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(admin)_dashboard_usuarios_page_tsx_8d9be5._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(admin)_dashboard_usuarios_page_tsx_8d9be5._.js",
  "chunks": [
    "static/chunks/node_modules_react-icons_lu_index_mjs_26d8a9._.js",
    "static/chunks/node_modules_react-icons_fa6_index_mjs_00e856._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_lodash-es_489b7f._.js",
    "static/chunks/node_modules_092840._.js",
    "static/chunks/_6a913c._.js"
  ],
  "source": "dynamic"
});
