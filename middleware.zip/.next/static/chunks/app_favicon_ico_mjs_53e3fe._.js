(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_favicon_ico_mjs_53e3fe._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_favicon_ico_mjs_53e3fe._.js",
  "chunks": [
    "static/chunks/_22d2ba._.js"
  ],
  "source": "dynamic"
});
