(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(admin)_layout_tsx_04199f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(admin)_layout_tsx_04199f._.js",
  "chunks": [
    "static/chunks/node_modules_d48fc9._.js",
    "static/chunks/_d1d37b._.js"
  ],
  "source": "dynamic"
});
