export interface ListUserInterface {
  id: number;
  names: string;
  last_names: string;
  celular: string;
  email: string;
  estado: string;
  rol: string;
  dni: string;
  edad: number;
}
