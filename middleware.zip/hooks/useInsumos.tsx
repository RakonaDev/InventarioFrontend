"use client"

import { useEffect, useState } from "react";

const fetchInsumos = async () => {
  const response = await fetch("http://localhost:8000/api/getInsumos", {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      'Authorization': `Bearer ${localStorage.getItem("token") || ''}`,
    },

  });
  const data = await response.json();
  return data;
};

export const useInsumos = () => {
  const [insumos, setInsumos] = useState<any[]>([]);
    useEffect(() => {
      fetchInsumos().then((data) => setInsumos(data));
    }, []);
    return { insumos, setInsumos};
}